<?php
return [
  'username' => 'tvůj_email@seznam.cz',
  'password' => 'tajneheslo123',
  'host' => 'smtp.seznam.cz',
  'port' => 587,
  'encryption' => 'tls'
];
