<?php /* očekává $menuByDay = ['pondělí' => ['Polévka'=>[...], ...], ...] */ ?>
<!DOCTYPE html>
<html lang="cs">
<head>
<meta charset="utf-8">
<style>
  body { font-family: DejaVu Sans, sans-serif; font-size: 12px; color:#1a202c; }
  .day-title { font-weight: bold; font-size: 16px; border-bottom: 2px solid #ecc94b; margin: 8px 0 4px; }
  .category { font-weight: bold; color: #d69e2e; text-transform: uppercase; margin: 6px 0 2px; }
  .item { display:flex; justify-content:space-between; border-bottom: 1px dashed #cbd5e0; padding: 2px 0; }
  .name { max-width:72%; }
  .price { font-weight:bold; color:#2f855a; white-space:nowrap; }
</style>
</head>
<body>
  <h1 style="text-align:center;margin:0 0 8px;">Jídelní lístek</h1>

  <?php foreach (['pondělí','úterý','středa','čtvrtek','pátek','sobota','neděle','stálá nabídka'] as $den): ?>
    <?php if (empty($menuByDay[$den])) continue; ?>
    <div class="day-title"><?= ucfirst($den) ?></div>
    <?php foreach ($menuByDay[$den] as $kat => $jidla): ?>
      <?php if (empty($jidla)) continue; ?>
      <div class="category"><?= htmlspecialchars($kat) ?></div>
      <?php foreach ($jidla as $j): ?>
        <div class="item">
          <div class="name">
            <?= htmlspecialchars($j['nazev']) ?>
            <?php if (!empty($j['gramaz'])): ?> (<?= htmlspecialchars($j['gramaz']) ?>)<?php endif; ?>
            <?php if (!empty($j['alergeny'])): ?> – A: <?= htmlspecialchars($j['alergeny']) ?><?php endif; ?>
          </div>
          <div class="price">
            <?php if ($kat === 'Polévka' && !empty($j['cenaPul'])): ?>
              <?= htmlspecialchars($j['cena']) ?> Kč / ½ <?= htmlspecialchars($j['cenaPul']) ?> Kč
            <?php else: ?>
              <?= htmlspecialchars($j['cena']) ?> Kč
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; ?>
    <?php endforeach; ?>
  <?php endforeach; ?>

  <div style="margin-top:12px;text-align:center;font-size:11px;color:#4a5568;border-top:1px solid #cbd5e0;padding-top:6px;">
    Provozovna: Družstevní 1435, 594 01 Velké Meziříčí • Tel: 566 503 848 • Email: ondrej.rada.bufet@seznam.cz
  </div>
</body>
</html>
