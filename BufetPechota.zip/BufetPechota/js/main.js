// === Sdílené proměnné ===
let dataSource = 'google';
let sheetId = '1D-QOHmp0SQ3QpQizBHysu0wxs_tmnDzDyZVjK-T4b_k';
let sheetName = 'Týden 1';
let mode = 'denni'; // nebo 'tydenni'
let posledniZdroj = null;
let inicializovano = false;

// === Společné funkce ===
async function loadConfig() {
  try {
    const response = await fetch('config.json?_=' + new Date().getTime(), { cache: "no-store" });
    const config = await response.json();
    dataSource = config.source || 'google';

    const zdrojTxt = document.getElementById('zdrojTxt');
    if (zdrojTxt) zdrojTxt.textContent = dataSource;
  } catch (err) {
    console.warn('Nepodařilo se načíst config.json, používám "google".');
    dataSource = 'google';
  }
}

function updateDateTime() {
  const now = new Date();
  const den = now.toLocaleDateString('cs-CZ', { weekday: 'long' });
  const datum = now.toLocaleDateString('cs-CZ');
  const cas = now.toLocaleTimeString('cs-CZ', { hour: '2-digit', minute: '2-digit' });
  const datetime = document.getElementById('datetime');
  if (datetime) datetime.textContent = `${den}, ${datum} ${cas}`;
}

function hlidejZmenuZdroj() {
  fetch('config.json?_=' + new Date().getTime())
    .then(res => res.json())
    .then(config => {
      const novyZdroj = config.source || 'google';
      if (inicializovano && novyZdroj !== posledniZdroj) {
        console.log('Změna zdroje – reload.');
        window.location.reload();
      }
      posledniZdroj = novyZdroj;
      inicializovano = true;
    })
    .catch(err => console.warn('Nepodařilo se zkontrolovat config.json:', err));
}

function prepniZdroj() {
  const nova = dataSource === 'google' ? 'excel' : 'google';
  fetch('update-config.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ source: nova })
  })
    .then(r => r.text())
    .then((res) => {
      if (res.trim() === 'OK') {
        dataSource = nova;
        document.getElementById('zdrojTxt').textContent = dataSource;
        loadData();
      } else {
        throw new Error(res);
      }
    })
    .catch(err => alert("Nepodařilo se přepnout zdroj dat: " + err));
}

// === Funkce z export.js (výchozí renderování jídel) ===
async function loadData() {
  let rows = [];
  document.getElementById('menu').innerHTML = '<div style="color:#888;">⏳ Načítám data...</div>';

  try {
    if (dataSource === 'google') {
      const url = `https://docs.google.com/spreadsheets/d/${sheetId}/gviz/tq?tqx=out:json&sheet=${sheetName}`;
      const response = await fetch(url);
      const text = await response.text();
      const json = JSON.parse(text.substring(47).slice(0, -2));
      rows = json.table.rows.map(r => r.c.map(c => c ? c.v : ''));
    } else {
      const response = await fetch(`${sheetName}.xlsx`);
      if (!response.ok) throw new Error('Soubor Excel nenalezen.');
      const arrayBuffer = await response.arrayBuffer();
      const workbook = XLSX.read(arrayBuffer, { type: 'array' });
      const sheet = workbook.Sheets[sheetName];
      if (!sheet) throw new Error('List s názvem "' + sheetName + '" nebyl nalezen.');
      rows = XLSX.utils.sheet_to_json(sheet, { header: 1 });
    }
  } catch (err) {
    document.getElementById("menu").innerHTML = `<div style="color:red;">❌ ${err.message}</div>`;
    console.error('Chyba při načítání dat:', err);
    return;
  }

  const dnes = new Date().toLocaleDateString('cs-CZ', { weekday: 'long' }).toLowerCase();
  const menuByDay = {};

  rows.forEach(([den, kategorie, nazev, gramaz, cena, cenaPul, alergeny, aktivni, prenest]) => {
    const denNormalized = den?.trim().toLowerCase();
    const jeStala = denNormalized === 'stálá nabídka';
    let zobrazit = false;

    if (aktivni?.toLowerCase().trim() === 'ano') {
      if (mode === 'denni') {
        const jeDnes = denNormalized === dnes;
        const jePrenesene = prenest?.toLowerCase().trim() === 'ano' && !jeStala;
        zobrazit = jeDnes || jePrenesene || jeStala;
      } else {
        zobrazit = !jeStala;
      }
    }

    if (zobrazit) {
      if (!menuByDay[denNormalized]) menuByDay[denNormalized] = {};
      if (!menuByDay[denNormalized][kategorie]) menuByDay[denNormalized][kategorie] = [];
      menuByDay[denNormalized][kategorie].push({ nazev, gramaz, cena, cenaPul, alergeny });
    }
  });

  render(menuByDay);
}

function render(menuByDay) {
  const container = document.getElementById('menu');
  container.innerHTML = '';
  const daysOrder = ['pondělí', 'úterý', 'středa', 'čtvrtek', 'pátek', 'sobota', 'neděle', 'stálá nabídka'];
  const dnes = new Date().toLocaleDateString('cs-CZ', { weekday: 'long' }).toLowerCase();

  daysOrder.forEach(den => {
    const denData = menuByDay[den];
    if (!denData) return;
    if (mode === 'denni' && den !== dnes && den !== 'stálá nabídka') return;

    const denBlock = document.createElement('div');
    const title = document.createElement('div');
    title.className = 'day-title';
    title.textContent = den.charAt(0).toUpperCase() + den.slice(1);
    denBlock.appendChild(title);

    Object.entries(denData).forEach(([kategorie, jidla]) => {
      const cat = document.createElement('div');
      cat.className = 'item-block';

      const catTitle = document.createElement('div');
      catTitle.className = 'category';
      catTitle.textContent = kategorie;
      cat.appendChild(catTitle);

      jidla.forEach(j => {
        const item = document.createElement('div');
        item.className = 'item';
        item.innerHTML = `
          <div class="name">${j.nazev}${j.gramaz ? ` (${j.gramaz})` : ''}${j.alergeny ? ` - A: ${j.alergeny}` : ''}</div>
          <div class="price">
            ${kategorie === 'Polévka' && j.cenaPul ? `${j.cena} Kč / ½ porce za ${j.cenaPul} Kč` : `${j.cena} Kč`}
          </div>`;
        cat.appendChild(item);
      });

      denBlock.appendChild(cat);
    });

    container.appendChild(denBlock);
  });
}

function toggleMode() {
  mode = mode === 'denni' ? 'tydenni' : 'denni';
  updateTitle();
  document.querySelector('#export-buttons button').textContent = `Přepnout: ${mode === 'denni' ? 'Týdenní' : 'Denní'}`;
  loadData();
}

function updateTitle() {
  const title = document.querySelector('.header h1');
  if (title) {
    title.textContent = `Jídelní lístek – ${mode === 'denni' ? 'Denní nabídka' : 'Týdenní nabídka'}`;
  }
}

function aktualizovat() {
  fetch("update.php", { method: "POST" })
    .then(res => res.text())
    .then(msg => document.getElementById("vysledek").innerText = msg)
    .catch(err => document.getElementById("vysledek").innerText = "❌ Chyba: " + err);
}

function hideElementsForExport() {
  document.querySelectorAll('#export-buttons, #export-source-switch, button, .no-export')
    .forEach(el => el.style.display = 'none');
}

function showElementsAfterExport() {
  document.querySelectorAll('#export-buttons, #export-source-switch, button, .no-export')
    .forEach(el => el.style.display = '');
}

function downloadCleanPDF() {
  hideElementsForExport();

  const element = document.getElementById('capture-area');

  const opt = {
    margin: [10, 10, 15, 10],
    filename: `jidelni-listek-${mode}.pdf`,
    image: { type: 'jpeg', quality: 0.98 },
    html2canvas: {
      scale: 2,
      useCORS: true,
      scrollX: 0,
      scrollY: 0,
      windowWidth: document.body.scrollWidth
    },
    jsPDF: {
      unit: 'mm',
      format: 'a4',
      orientation: 'portrait'
    },
    pagebreak: {
      mode: ['avoid-all', 'css', 'legacy']
    }
  };

  html2pdf()
    .set(opt)
    .from(element)
    .save()
    .then(() => {
      showElementsAfterExport();
    })
    .catch(err => {
      console.error('Chyba při exportu PDF:', err);
      showElementsAfterExport();
    });
}

function downloadWord() {
  hideElementsForExport();

  const content = document.getElementById('capture-area').cloneNode(true);

  const styles = `
    <style>
      body { font-family: 'Segoe UI', sans-serif; font-size: 14px; }
      .header { display: flex; align-items: center; justify-content: center; gap: 1rem; margin-bottom: .5rem; }
      .header h1 { font-size: 1.8rem; font-weight: bold; color: #2f855a; text-align: center; }
      .day-title { font-size: 1.1rem; font-weight: bold; color: #1a202c; border-bottom: 2px solid #ecc94b; padding-bottom: 0.3rem; margin-top: .2rem; margin-bottom: 0.2rem; }
      .item-block { margin-bottom: 0.4rem; }
      .category { font-weight: bold; color: #d69e2e; margin-bottom: 0.1rem; text-transform: uppercase; font-size: 0.95rem; }
      .item { margin-left: 1rem; display: flex; justify-content: space-between; border-bottom: 1px dashed #cbd5e0; padding: 0.1rem 0; }
      .item .name { font-weight: 500; color: #2d3748; max-width: 70%; }
      .item .price { font-weight: bold; color: #2f855a; text-align: right; white-space: nowrap; }
      .footer { text-align: center; font-size: 0.85rem; color: #4a5568; border-top: 1px solid #cbd5e0; padding-top: 0.5rem; margin-top: 1rem; }
      img { height: 60px; object-fit: contain; }
    </style>
  `;

  const html = `
    <html xmlns:o='urn:schemas-microsoft-com:office:office'
          xmlns:w='urn:schemas-microsoft-com:office:word'
          xmlns='http://www.w3.org/TR/REC-html40'>
    <head><meta charset='utf-8'>${styles}</head>
    <body>${content.innerHTML}</body></html>`;

  const blob = new Blob([html], { type: 'application/msword' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `jidelni-listek-${mode}.doc`;
  link.click();

  showElementsAfterExport();
}

function toggleDarkMode() {
  document.body.classList.toggle('dark-mode');
}


function downloadPNG() {
  hideElementsForExport();
  const target = document.getElementById('capture-area');
  const buttons = document.getElementById('export-buttons');

  buttons.style.display = 'none';

  html2canvas(target, {
    backgroundColor: '#ffffff',
    scale: 2
  }).then(canvas => {
    const link = document.createElement('a');
    link.download = `jidelni-listek-${mode}.png`;
    link.href = canvas.toDataURL();
    link.click();

    buttons.style.display = 'flex';
    showElementsAfterExport();
  });
}


// Export functions (downloadCleanPDF, downloadWord, downloadStyledExcel, downloadPNG)
// zde raději ponechám samostatně, protože mají hodně HTML interakce – chceš i tyto spojit?

// === Inicializace ===
document.addEventListener('DOMContentLoaded', async () => {
  updateDateTime();
  await loadConfig();
  const ind = document.getElementById('data-indicator');
if (ind) ind.style.backgroundColor = (dataSource === 'excel' ? '#1D6F42' : '#4285F4');

  await loadData();
  setInterval(updateDateTime, 10000);
  setInterval(loadData, 60000);
  setInterval(hlidejZmenuZdroj, 5000);
});
