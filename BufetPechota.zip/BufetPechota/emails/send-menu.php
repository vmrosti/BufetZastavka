<?php
declare(strict_types=1);

use Dompdf\Dompdf;
use Dompdf\Options;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/../vendor/autoload.php';
$config = require __DIR__ . '/config.php';

if (!isset($_GET['token']) || $_GET['token'] !== $config['admin_token']) {
  http_response_code(403);
  exit('Forbidden');
}

// 1) Konfigurace zdroje
$cfgJson = json_decode(file_get_contents(__DIR__ . '/../config.json'), true);
$dataSource = $cfgJson['source'] ?? 'google';

// 2) Načtení e-mailů
$emailPath = __DIR__ . '/../emails/emails.json';
$emailData = json_decode(file_get_contents($emailPath), true);
$recipients = $emailData['to'] ?? [];
$subject    = $emailData['subject'] ?? 'Denní jídelní lístek';
$messageTxt = $emailData['message'] ?? 'Jídelní lístek v příloze.';

// 3) Načti data menu (Google Sheets GVIZ)
$sheetId   = '1D-QOHmp0SQ3QpQizBHysu0wxs_tmnDzDyZVjK-T4b_k';
$sheetName = 'Týden 1';

$rows = [];
if ($dataSource === 'google') {
  $url = "https://docs.google.com/spreadsheets/d/{$sheetId}/gviz/tq?tqx=out:json&sheet=".rawurlencode($sheetName);
  $txt = @file_get_contents($url);
  if ($txt === false) {
    http_response_code(500);
    exit('Chyba při načítání Google Sheets.');
  }
  $json = json_decode(substr($txt, 47, -2), true);
  $rows = array_map(function($r){
    return array_map(fn($c)=> $c['v'] ?? '', $r['c']);
  }, $json['table']['rows'] ?? []);
} else {
  // Volitelné: PHPSpreadsheet pro server-side Excel
  http_response_code(501);
  exit('Server-side Excel zatím není povolen. Přepni source na "google" nebo doinstaluj PHPSpreadsheet.');
}

// 4) Připrav menuByDay (stejné členění jako v JS)
$menuByDay = [];
$now = new DateTime('now', new DateTimeZone('Europe/Prague'));
$dnes = mb_strtolower($now->format('l'), 'UTF-8'); // anglicky; pokud chceš česky, použij IntlDateFormatter
// mapovat na cs:
$map = ['monday'=>'pondělí','tuesday'=>'úterý','wednesday'=>'středa','thursday'=>'čtvrtek','friday'=>'pátek','saturday'=>'sobota','sunday'=>'neděle'];
$dnesCS = $map[$dnes] ?? 'pondělí';

foreach ($rows as $r) {
  [$den,$kategorie,$nazev,$gramaz,$cena,$cenaPul,$alergeny,$aktivni,$prenest] = array_pad($r, 9, '');
  $denN = mb_strtolower(trim((string)$den), 'UTF-8');
  $isStala = ($denN === 'stálá nabídka');

  $show = false;
  if (mb_strtolower((string)$aktivni, 'UTF-8') === 'ano') {
    // Default: denní režim = dnešek + přenesené + stálá
    $jeDnes = ($denN === $dnesCS);
    $jePrenesene = (mb_strtolower((string)$prenest,'UTF-8') === 'ano') && !$isStala;
    $show = $jeDnes || $jePrenesene || $isStala;
  }

  if ($show) {
    $menuByDay[$denN] ??= [];
    $menuByDay[$denN][$kategorie] ??= [];
    $menuByDay[$denN][$kategorie][] = [
      'nazev'=>$nazev,'gramaz'=>$gramaz,'cena'=>$cena,'cenaPul'=>$cenaPul,'alergeny'=>$alergeny
    ];
  }
}

// 5) Render PDF HTML přes šablonu
ob_start();
$__menuByDay = $menuByDay;
$menuByDay = $__menuByDay; // do local scope
include __DIR__ . '/pdf-template.php';
$html = ob_get_clean();

// 6) Dompdf
$options = new Options();
$options->set('isRemoteEnabled', true);
$dompdf = new Dompdf($options);
$dompdf->loadHtml($html, 'UTF-8');
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$pdfContent = $dompdf->output();
$pdfPath = __DIR__ . '/jidelnicek.pdf';
file_put_contents($pdfPath, $pdfContent);

// 7) PHPMailer
$mail = new PHPMailer(true);
try {
  $mail->isSMTP();
  $mail->Host = $config['smtp']['host'];
  $mail->SMTPAuth = true;
  $mail->Username = $config['smtp']['user'];
  $mail->Password = $config['smtp']['pass'];
  $mail->SMTPSecure = $config['smtp']['secure'];
  $mail->Port = (int)$config['smtp']['port'];
  $mail->setFrom($config['smtp']['from'], $config['smtp']['from_name']);
  $mail->Subject = $subject;
  $mail->Body = $messageTxt;

  foreach ($recipients as $email) {
    $mail->clearAllRecipients();
    $mail->addAddress($email);
    $mail->addAttachment($pdfPath, 'jidelni-listek.pdf');
    $mail->send();
  }
  echo 'Emaily odeslány.';
} catch (Exception $e) {
  http_response_code(500);
  echo 'Chyba při odesílání: '.$mail->ErrorInfo;
}
