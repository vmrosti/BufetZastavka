<?php
$token = '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'; // ⚠️ Tvůj token
$user = 'vmrosti';
$repo = 'BufetZastavka';
$branch = 'main';

$files = [
    'index.html',
    'export.html',
    'config.json',
    'update-config.php',
];

$successes = [];
$errors = [];

foreach ($files as $file) {
    $url = "https://api.github.com/repos/$user/$repo/contents/$file?ref=$branch";

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // ⚠️ DŮLEŽITÉ PRO HOSTINGY
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: token $token",
        "User-Agent: GitHubAutoUpdateScript"
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    if ($httpCode === 200) {
        $json = json_decode($response, true);
        if (!isset($json['content'])) {
            $errors[] = "Chybná odpověď při stahování $file – 'content' není přítomen.";
            continue;
        }

        $decoded = base64_decode($json['content']);

        $savePath = __DIR__ . DIRECTORY_SEPARATOR . $file;
        if (file_put_contents($savePath, $decoded) !== false) {
            $successes[] = $file;
        } else {
            $errors[] = "Nelze uložit $file";
        }
    } else {
        $errors[] = "Chyba při stahování $file (HTTP $httpCode): $curlError";
    }
}

if (!empty($successes)) {
    echo "✅ Aktualizováno: " . implode(', ', $successes);
}
if (!empty($errors)) {
    echo "\n❌ Chyby:\n" . implode("\n", $errors);
}
